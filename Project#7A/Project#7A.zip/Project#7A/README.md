Instructions:
1. This program is built for an Apple laptop so in order to run it on another OS you'll need to make some changes.
2. Navigate to the directory with these files and run "make"
3. That should create a "sample" executable file and by running "./sample" you can interact with the particle simulator.
4. I wasn't sure if the GLUT header files were important so I just included them anyway.