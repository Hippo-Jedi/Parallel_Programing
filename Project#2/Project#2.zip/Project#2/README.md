Instructions:

1. Change the numer of nodes and number of threads to whatever you like, then run "Make" to creake a ./main file

2. Run "./main" to see the outputs

3. If you wish to write mutiple runs to a .csv file, uncomment line 131 and comment out lines 128 and 130

4. Then run "csh loop >& proj1.csv" to create and write to the .csv file